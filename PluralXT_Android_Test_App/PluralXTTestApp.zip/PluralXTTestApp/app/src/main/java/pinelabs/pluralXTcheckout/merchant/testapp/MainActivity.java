package pinelabs.pluralXTcheckout.merchant.testapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import pinelabs.pluralXTcheckout.sdk.PluralXTCheckoutManager;
import pinelabs.pluralXTcheckout.sdk.ServiceLayer.Abstract.IPluralXTCheckoutCallbacks;
import pinelabs.pluralXTcheckout.sdk.annotations.PluralXTBaseUrlTypeAnnotation;

public class MainActivity extends AppCompatActivity {
    Button payNowButton;
    int txnid;
    private AlertDialog.Builder responseDisplayDialogue;
    private TextView tvPaymentStatus,tvErrorCode,tvErrorMessage, tvIsBackButtonPreesed,tvMerchantId,tvTransactionId;
    private View alertLayout;
    private EditText text,paymentMode;
    private static String TAG="MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        payNowButton=findViewById(R.id.payNow);
        text=findViewById(R.id.Token);
        paymentMode=findViewById(R.id.PaymentMode);
        paymentMode.setText("ALL");
        payNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value=text.getText().toString();
                String paymentModeValue=paymentMode.getText().toString();
                PluralXTCheckoutManager.getInstance().setContext(MainActivity.this);
                PluralXTCheckoutManager.getInstance().startPaymentService(pluralXTCheckoutCallbacks, PluralXTBaseUrlTypeAnnotation.TEST,paymentModeValue,value);
            }
        });
        initializeAlertLayout();


        paymentMode.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus){
                    hideKeyboard();
                }
            }
        });


    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(paymentMode.getWindowToken(), 0);
    }

    private IPluralXTCheckoutCallbacks pluralXTCheckoutCallbacks=new IPluralXTCheckoutCallbacks() {
        @Override
        public void onErrorOccurred(int i, String s) {
            System.out.println(s);
            showResponseDialogue();
            tvErrorCode.setText(i+"");
            tvErrorMessage.setText(s);
        }
        @Override
        public void onTransactionResponse(Bundle bundle) {
            showResponseDialogue();
            tvIsBackButtonPreesed.setText("No");
            tvPaymentStatus.setText("Completed");
        }

        @Override
        public void onCancelTxn() {
            showResponseDialogue();
        }

        @Override
        public void onPressedBackButton() {
            showResponseDialogue();
            tvIsBackButtonPreesed.setText("Yes");
        }

        @Override
        public void onPageStarted(WebView webView, String s) {
            showResponseDialogue();
        }

        @Override
        public void onWebViewReady(WebView webView) {

        }
    };
    private void initializeAlertLayout()
    {
        try {
            if(this.alertLayout==null) {
                LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                this.alertLayout = inflater.inflate(R.layout.callback_reponse_dialogue, null);
                this.tvPaymentStatus = this.alertLayout.findViewById(R.id.tvPaymentStatus);
                this.tvErrorCode = this.alertLayout.findViewById(R.id.tvErrorCode);
                this.tvErrorMessage=this.alertLayout.findViewById(R.id.tvErrorMessage);
                this.tvIsBackButtonPreesed =this.alertLayout.findViewById(R.id.tvIsBackPressed);
                this.tvMerchantId=this.alertLayout.findViewById(R.id.tvMerchantId);
                this.tvTransactionId=this.alertLayout.findViewById(R.id.tvTransactionId);
            }
        }
        catch (Exception ex)
        {

        }
    }
    private void showResponseDialogue()
    {
        try {
            initializeAlertLayout();
            if(this.responseDisplayDialogue==null) {
                this.responseDisplayDialogue = new AlertDialog.Builder(this);
                this.responseDisplayDialogue.setTitle("Callback Response");
                this.responseDisplayDialogue.setCancelable(true);
                this.responseDisplayDialogue.setView(this.alertLayout);
                this.responseDisplayDialogue.setNegativeButton("close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
            }
            this.tvTransactionId.setText(txnid+"");
            responseDisplayDialogue.show();
        }
        catch (Exception ex)
        {
            Log.e(TAG,ex.getMessage());
        }
    }
}
